1. Take input as geojson format
2. upload to /files
3. Plot traces

DONE
*********************


4. Call MapMatching Function
5. Plot output traces with new color
6. Download output file
